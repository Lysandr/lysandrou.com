

I used the CEEVEE template from style shout. I want to make sure to credit them here:




##################################################################
##################################################################
LICENSE:

CEEVEE is released under the Creative Commons Attribution 3.0 License
(http://creativecommons.org/licenses/by/3.0/). This means that you are free:

   to Share - to copy, distribute, display, and perform the work
   to Remix - to make derivative works
   to make commercial use of the work 

Under the following conditions:

   Attribution - You must attribute the work in the manner specified by the 
   author or licensor (but not in any way that suggests that they endorse you 
   or your use of the work). 

   For any reuse or distribution, you must make clear to others the license 
   terms of this work

   Any of these conditions can be waived if you get permission from the 
   copyright holder

Attribution: 
	
   You must include a credit link to our website(http://www.Styleshout.com) somewhere on
   your site. We prefer the footer credit that comes with the template but you are still 
   free to move it somewhere else.


SOURCES AND CREDITS:

I've used the following resources as listed.

Fonts:
 - Open Sans Font (http://www.google.com/fonts/specimen/Open+Sans)
 - Libre Baskerville Font (http://www.google.com/fonts/specimen/Libre+Baskerville) 

Icons:
 - Font Awesome (http://fortawesome.github.io/Font-Awesome/)
 - Fontello (http://fontello.com/)

Stock Photos and Graphics:
 - UnSplash.com (http://unsplash.com/)
 - Morguefile.com (http://www.morguefile.com/)

Javascript Files:

 - JQuery (http://jquery.com/)
 - FlexSlider by Woothemes (http://www.woothemes.com/flexslider/)
 - Modernizr (http://modernizr.com/)
 - FitText (http://fittextjs.com/) 
 - Magnific Popup (http://dimsemenov.com/plugins/magnific-popup/)
 - jQuery Waypoints (http://imakewebthings.com/jquery-waypoints/)

  

